<?php
if (session_status() == PHP_SESSION_NONE) session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Ajouter une matière
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['subject_name'])) {
    $name = trim($_POST['subject_name']);
    if ($name !== '') {
        $stmt = $conn->prepare("INSERT INTO subjects(subject_name) VALUES(?)");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        header("Location: subjects.php");
        exit;
    }
}

// Supprimer une matière
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM subjects WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: subjects.php");
    exit;
}

// Récupérer toutes les matières
$subjects = $conn->query("SELECT * FROM subjects ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Manage Subjects</title>
<style>
/* Copier le CSS complet du dashboard ici */
:root{
  --bg:#f4f6f8; --card:#ffffff; --muted:#6b7280; --primary:#0d6efd; --accent:#10b981; --danger:#ef4444; --text:#111827;
}
body.dark{--bg:#0b1220;--card:#071025;--muted:#94a3b8;--primary:#60a5fa;--accent:#34d399;--danger:#fb7185;--text:#e6eef8;}
*{box-sizing:border-box} html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--text);}
.container{display:flex;min-height:100vh;}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:260px;background:linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01));backdrop-filter: blur(6px);transform:translateX(-320px);transition:transform .28s ease, box-shadow .28s;padding:22px;z-index:40;box-shadow: 0 10px 30px rgba(2,6,23,0.18);}
.sidebar.open{transform:translateX(0);}
.brand{display:flex;align-items:center;gap:12px;margin-bottom:18px}
.brand .logo{width:46px;height:46px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.brand h3{margin:0;font-size:18px}
.sidebar .nav{margin-top:12px;display:flex;flex-direction:column;gap:8px}
.nav a{display:flex;align-items:center;gap:12px;padding:12px;border-radius:10px;color:var(--text);text-decoration:none;font-weight:600;transition:background .18s,color .18s,transform .12s;}
.nav a svg{width:20px;height:20px;opacity:0.9}
.nav a:hover{background:rgba(255,255,255,0.04);transform:translateX(4px)}
.nav a.active{background:var(--primary);color:white;box-shadow:0 6px 18px rgba(13,110,253,0.12)}
.sidebar .closeBtn{position:absolute;right:-46px;top:14px;background:var(--card);border-radius:10px;padding:10px;box-shadow:0 6px 18px rgba(2,6,23,0.12);cursor:pointer}
.main{margin-left:0;width:100%;padding:26px;transition:margin-left .28s ease;min-height:100vh;}
.sidebar.open ~ .main{margin-left:260px}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}
.top-left{display:flex;align-items:center;gap:12px}
.menuBtn{background:var(--card);border-radius:10px;padding:10px;cursor:pointer;box-shadow:0 6px 18px rgba(2,6,23,0.06)}
.userBox{display:flex;align-items:center;gap:12px}
.userAvatar{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:700}
.card{background:var(--card);padding:20px;border-radius:14px;box-shadow:0 6px 24px rgba(2,6,23,0.06);margin-top:20px;}
.add-btn{padding:10px 16px;background:var(--primary);color:#fff;border:none;border-radius:8px;cursor:pointer;margin-bottom:12px;}
.add-btn:hover{background:#0b5ed7;}
table{width:100%;border-collapse:collapse;}
th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left;}
th{background:#f0f0f0;}
</style>
</head>
<body>
<div class="container">
  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="logo">AS</div>
      <h3>AbsenceSys</h3>
    </div>
    <div class="nav">
      <a href="dashboard.php" title="Dashboard"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>Dashboard</a>
      <a href="classes.php" title="Classes"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L1 7l11 5 9-4.09V17h2V7L12 2z"/></svg>Classes</a>
      <a href="students.php" title="Students"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>Students</a>
      <a href="subjects.php" class="active" title="Subjects"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 3H3v2h18V3zM3 19h18v-2H3v2zM3 7h18v10H3V7z"/></svg>Subjects</a>
      <a href="absence_add.php" title="Add absence"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5c0-1.1-.9-2-2-2zM7 12h10v2H7z"/></svg>Add Absence</a>
      <a href="absence_list.php" title="View absences"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 13h8v-2H3v2zm0 6h8v-2H3v2zM3 7h8V5H3v2zm10 6h8v-2h-8v2zm0 6h8v-2h-8v2z"/></svg>View Absences</a>
      <a href="logout.php" title="Logout" style="color:var(--danger);margin-top:10px;"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 13v-2H7V8l-5 4 5 4v-3zM20 3h-8v2h8v14h-8v2h8a2 2 0 002-2V5a2 2 0 00-2-2z"/></svg>Logout</a>
    </div>
    <div class="closeBtn" id="closeSidebar"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg></div>
  </aside>

  <!-- Main -->
  <main class="main">
    <div class="topbar">
      <div class="top-left">
        <div class="menuBtn" id="openSidebar">&#9776;</div>
        <h2 style="margin:0">Manage Subjects</h2>
      </div>
      <div class="userBox">
        <div><?php echo htmlspecialchars($_SESSION['user']); ?></div>
        <div class="userAvatar"><?php echo strtoupper(substr($_SESSION['user'],0,1)); ?></div>
      </div>
    </div>

    <button class="add-btn" onclick="document.getElementById('addBox').style.display='block'">+ Add Subject</button>

    <div id="addBox" style="display:none;margin-bottom:12px;">
      <form method="POST">
        <input type="text" name="subject_name" placeholder="Subject Name" required style="padding:10px;border-radius:8px;border:1px solid #ddd;">
        <button class="add-btn" type="submit">Save</button>
        <button type="button" onclick="document.getElementById('addBox').style.display='none'" style="padding:10px;border-radius:8px;border:1px solid #ddd;">Cancel</button>
      </form>
    </div>

    <div class="card">
      <table>
        <thead><tr><th>ID</th><th>Subject Name</th><th>Actions</th></tr></thead>
        <tbody>
        <?php while($row = $subjects->fetch_assoc()): ?>
          <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
            <td><a href="subjects.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Delete?')">Delete</a></td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<script>
var sidebar = document.getElementById('sidebar');
document.getElementById('openSidebar').addEventListener('click', function(){ sidebar.classList.toggle('open'); });
document.querySelector('.closeBtn').addEventListener('click', function(){ sidebar.classList.remove('open'); });
</script>
</body>
</html>
