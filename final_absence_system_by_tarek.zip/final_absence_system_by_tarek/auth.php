<?php
session_start();
require 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT password FROM users WHERE username=?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->bind_result($hash);

if ($stmt->fetch() && password_verify($password, $hash)) {
    $_SESSION['user'] = $username;
    header("Location: dashboard.php");
} else {
    $_SESSION['error'] = "Invalid login";
    header("Location: login.php");
}
exit;
?>
