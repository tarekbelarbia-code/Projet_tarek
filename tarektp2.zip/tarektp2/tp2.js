
(function(){
  const STORAGE_KEY="attendance_pro_final";
  const SESSION_COUNT=6, PART_COUNT=6;
  let data = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [
    {id:"1001",last:"Ahmed",first:"Sara",email:"sara.ahmed@example.com",
     sessions:[true,true,false,false,false,false],
     parts:[true,false,false,false,false,false]},
    {id:"1002",last:"Yacine",first:"Ali",email:"yacine.ali@univ-alger1.dz",
     sessions:[true,true,true,true,true,true],
     parts:[true,true,true,true,false,true]}
  ];

  const save=()=>localStorage.setItem(STORAGE_KEY,JSON.stringify(data));
  const $tbody=$("#attendanceTable tbody");
  const toast=document.getElementById("toast");
  const showToast=msg=>{toast.textContent=msg;toast.style.opacity=1;setTimeout(()=>toast.style.opacity=0,2000);};

  function render(){
    $tbody.empty();
    data.forEach((s,i)=>{
      const tr=$("<tr>").attr("data-index",i);
      tr.append(`<td>${s.id}</td><td>${s.last}</td><td>${s.first}</td>`);
      for(let j=0;j<SESSION_COUNT;j++)
        tr.append(`<td class='session-cell' title='Click to toggle presence'>${s.sessions[j]?"✓":""}</td>`);
      for(let j=0;j<PART_COUNT;j++)
        tr.append(`<td class='part-cell' title='Click to toggle participation'>${s.parts[j]?"P":""}</td>`);
      tr.append("<td class='abs-cell'></td><td class='par-cell'></td><td class='msg-cell'></td>");
      tr.append("<td><button class='delete-btn' title='Remove student'>🗑️</button></td>");
      $tbody.append(tr);
    });
    updateStats();
  }

  function updateStats(){
    $tbody.find("tr").each(function(){
      const i=$(this).data("index");
      const s=data[i];
      const present=s.sessions.filter(Boolean).length;
      const abs=SESSION_COUNT-present;
      const par=s.parts.filter(Boolean).length;
      $(this).find(".abs-cell").text(abs+" Abs");
      $(this).find(".par-cell").text(par+" Par");
      $(this).removeClass("row-good row-warning row-bad");
      let msg="";
      if(abs<3){$(this).addClass("row-good");msg=par>=4?"Excellent":"Good";}
      else if(abs<=4){$(this).addClass("row-warning");msg="Warning";}
      else{$(this).addClass("row-bad");msg="Excluded";}
      $(this).find(".msg-cell").text(msg);
    });
  }

  // Toggle attendance/participation
  $tbody.on("click",".session-cell,.part-cell",function(e){
    e.stopPropagation();
    const tr=$(this).closest("tr"),i=tr.data("index"),idx=$(this).index();
    if($(this).hasClass("session-cell")) data[i].sessions[idx-3]=!data[i].sessions[idx-3];
    else data[i].parts[idx-9]=!data[i].parts[idx-9];
    save();render();showToast("Updated ✓");
  });

  // Remove student
  $tbody.on("click",".delete-btn",function(e){
    e.stopPropagation();
    const i=$(this).closest("tr").data("index");
    const s=data[i];
    if(confirm(`Remove ${s.first} ${s.last}?`)){
      data.splice(i,1);
      save();render();showToast("Student removed 🗑️");
    }
  });

  // Add student
  $("#studentForm").on("submit",function(e){
    e.preventDefault();
    const id=$("#studentId").val().trim(),
          last=$("#lastName").val().trim(),
          first=$("#firstName").val().trim(),
          email=$("#email").val().trim();
    $(".error").text("");
    let ok=true;
    if(!/^[0-9]+$/.test(id)){ok=false;$("#idError").text("ID must be numbers.");}
    if(!/^[A-Za-z]+$/.test(last)){ok=false;$("#lastError").text("Letters only.");}
    if(!/^[A-Za-z]+$/.test(first)){ok=false;$("#firstError").text("Letters only.");}
    if (!/^[\w.-]+@[\w.-]+\.\w{2,}$/.test(email)) {
  valid = false;
  document.getElementById("emailError").textContent = "Invalid email format";
}

    if(!ok)return;
    data.push({id,last,first,email,sessions:Array(6).fill(false),parts:Array(6).fill(false)});
    save();render();this.reset();showToast("Student added ✅");
  });

  // Report
  $("#showReportBtn").on("click",function(){
    updateStats();
    const total=data.length;
    let pres=0,par=0;
    data.forEach(s=>{pres+=s.sessions.filter(Boolean).length;par+=s.parts.filter(Boolean).length;});
    $("#reportText").text(`Total ${total} | Presences ${pres} | Participations ${par}`);
    $("#reportSection").show();
    const ctx=document.getElementById("reportChart").getContext("2d");
    if(window.rep)window.rep.destroy();
    window.rep=new Chart(ctx,{type:"bar",
      data:{labels:["Students","Presences","Participations"],
      datasets:[{label:"Report",data:[total,pres,par],
      backgroundColor:["#0069ff","#16a34a","#f59e0b"]}]},
      options:{scales:{y:{beginAtZero:true}}}});
  });

  // Highlight / Reset
  $("#highlightBtn").on("click",function(){
    updateStats();
    $tbody.find("tr").each(function(){
      if($(this).hasClass("row-good"))$(this).fadeTo(200,0.3).fadeTo(200,1);
    });
  });
  $("#resetBtn").on("click",function(){render();showToast("Reset done 🔄");});

  render();
})();
