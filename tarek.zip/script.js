document.getElementById('studentForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const studentID = this.studentID.value.trim();
  const lastName = this.lastName.value.trim();
  const firstName = this.firstName.value.trim();
  const email = this.email.value.trim();
  const tbody = document.querySelector('#attendance-list tbody');
  const existingIds = Array.from(tbody.rows).map(row => row.cells[0].textContent);
  if (existingIds.includes(studentID)) {
    alert('Student ID already exists in the attendance list!');
    return;
  }
  const newRow = tbody.insertRow();
  newRow.insertCell(0).textContent = studentID;
  newRow.insertCell(1).textContent = lastName;
  newRow.insertCell(2).textContent = firstName;
  newRow.insertCell(3).textContent = 'N/A';
  newRow.insertCell(4).textContent = '❌';
  newRow.insertCell(5).textContent = '❌';
  this.reset();
  alert(`Student ${firstName} ${lastName} added successfully!`);
});